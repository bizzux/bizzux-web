import Link from "next/link";

// Nav for the SaaS app section's own public-ish pages (/apps, and the
// pricing plan grid) — ported from apps.bizzux.com's shared Nav component.
// Renamed to AppNav (not Nav) so it doesn't collide with bizzux.com's own
// marketing components/Nav.tsx; "Sign in" now points at /sign-in per the
// merged path.
export default function AppNav() {
  return (
    <nav className="nav">
      <div className="nav-inner">
        <Link href="/"><img src="/app-logo.png" alt="Bizzux" className="logo-img" /></Link>
        <div className="nav-links">
          <Link href="/apps">All apps</Link>
          <Link href="/pricing">Pricing</Link>
          <Link href="/sign-in">Sign in</Link>
          <Link href="/sign-in?mode=signup" className="btn-primary" style={{ padding: "9px 20px", fontSize: 13.5 }}>
            Start free trial
          </Link>
        </div>
      </div>
    </nav>
  );
}
